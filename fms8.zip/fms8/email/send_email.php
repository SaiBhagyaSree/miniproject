<?php
require '../vendor/PHPMailer-master/src/PHPMailer.php';
require '../vendor/PHPMailer-master/src/SMTP.php';
require '../vendor/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$email = $_GET['email'];
$username = $_GET['username'];
$password = $_GET['password'];

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'allampallysaibhagyasree@gmail.com'; // Replace with your SMTP username
    $mail->Password   = 'saibhagyasree@2002'; // Replace with your SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom('allampallysaibhagyasree@gmail.com', 'GcetAdmin');
    $mail->addAddress($email); 

    $mail->isHTML(true);
    $mail->Subject = 'New Account Details';
    $mail->Body    = "Username: $username<br>Password: $password";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>

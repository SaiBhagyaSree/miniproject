<?php
session_start();
if (!isset($_SESSION['hod_logged_in'])) {
    header('Location: hod_login.php');
    exit();
}

// Include the database connection file
require '../includes/db.php';

// Get the HOD's department from the hods table
$hod_id = $_SESSION['hod_id'];
$query = "SELECT department FROM hods WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $hod_id);
$stmt->execute();
$result = $stmt->get_result();
$hod = $result->fetch_assoc();
$department = $hod['department'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Faculty</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        .container {
            display: flex;
            height: 100vh;
        }

        .left-frame {
            width: 25%;
            background-color: #343a40;
            color: #ffffff;
            padding: 20px;
            box-sizing: border-box;
        }

        .left-frame ul {
            list-style-type: none;
            padding: 0;
        }

        .left-frame li {
            margin-bottom: 20px;
        }

        .left-frame a {
            color: #ffffff;
            text-decoration: none;
            display: block;
            padding: 10px;
            background-color: #495057;
            text-align: center;
            border-radius: 5px;
        }

        .left-frame a:hover {
            background-color: #adb5bd;
        }

        .right-frame {
            width: 75%;
            padding: 20px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #dddddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }
    </style>
    <script>
        function loadContent(url) {
            document.getElementById('right-frame').src = url;
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="left-frame">
            <ul>
                <li><a href="#" onclick="loadContent('view_faculty.php')">View Faculty</a></li>
                <li><a href="#" onclick="loadContent('filter_faculty.php')">Filter Faculty</a></li>
            </ul>
        </div>
        <iframe id="right-frame" class="right-frame" src=""></iframe>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filter Faculty</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f0f2f5;
        }
        h1 {
            color: #007bff;
            text-align: center;
        }
        form {
            margin-top: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .filter-group {
            margin-bottom: 15px;
        }
        .filter-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .filter-group input, .filter-group select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        .filter-group .checkbox-group {
            display: flex;
            gap: 15px;
        }
        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Filter Faculty Members</h1>
    
    <form action="filter_processing.php" method="POST">
        <!-- Filter for Age -->
        <div class="filter-group">
            <label for="age">Age</label>
            <select name="age_operator">
                <option value="=">=</option>
                <option value="<"><</option>
                <option value=">">></option>
            </select>
            <input type="number" name="age" placeholder="Enter age">
        </div>

        <!-- Filter for Date of Joining -->
        <div class="filter-group">
            <label for="doj">Date of Joining</label>
            <input type="month" name="doj" placeholder="Select Date">
        </div>

        <!-- Filter for Qualification -->
        <div class="filter-group">
            <label for="qualification">Qualification</label>
            <input type="text" name="qualification" placeholder="Enter qualification">
        </div>

        <!-- Filter for Specialization -->
        <div class="filter-group">
            <label for="specialization">Specialization</label>
            <input type="text" name="specialization" placeholder="Enter specialization">
        </div>

        <!-- Filter for Experience -->
        <div class="filter-group">
            <label for="experience">Experience (Years)</label>
            <select name="experience_operator">
                <option value="=">=</option>
                <option value="<"><</option>
                <option value=">">></option>
            </select>
            <input type="number" name="experience" placeholder="Enter years of experience">
        </div>

        <!-- Filter for University -->
        <div class="filter-group">
            <label for="university">University</label>
            <input type="text" name="university" placeholder="Enter university name">
        </div>

        <!-- Filter for Designation -->
        <div class="filter-group">
            <label for="designation">Designation</label>
            <input type="text" name="designation" placeholder="Enter designation">
        </div>

        <!-- Filter for Currently Teaching -->
        <div class="filter-group">
            <label for="currently_teaching">Currently Teaching</label>
            <input type="text" name="currently_teaching" placeholder="Enter subject">
        </div>

        <!-- Submit Button -->
        <button type="submit">Filter</button>
    </form>
</body>
</html>

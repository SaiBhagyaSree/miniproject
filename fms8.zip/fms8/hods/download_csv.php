<?php
if (isset($_POST['faculty_data'])) {
    // Unserialize the faculty data from the hidden input field
    $faculty_data = unserialize(base64_decode($_POST['faculty_data']));
    
    // Set headers to prompt download of the CSV file
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="faculty_data.csv"');

    // Open the output stream
    $output = fopen('php://output', 'w');

    // Set the header row for the CSV
    fputcsv($output, ['First Name', 'Last Name', 'Email', 'Age', 'Qualification', 'Specialization', 'Experience', 'University', 'Designation', 'Currently Teaching']);

    // Populate the CSV with faculty data
    foreach ($faculty_data as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
} else {
    echo "No data to export.";
}
?>

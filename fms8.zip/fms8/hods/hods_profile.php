<?php
session_start(); // Start the session
include('../includes/db.php'); // Include the database connection file

// Initialize variable for error message
$errorMessage = '';

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize variables, checking if fields are set
    $designation = isset($_POST['designation']) ? $_POST['designation'] : '';
    $age = isset($_POST['age']) ? $_POST['age'] : '';
    $specialization = isset($_POST['specialization']) ? $_POST['specialization'] : '';
    $university = isset($_POST['university']) ? $_POST['university'] : '';
    $currently_teaching = isset($_POST['currently_teaching']) ? $_POST['currently_teaching'] : '';
    $portfolio = isset($_POST['portfolio']) ? $_POST['portfolio'] : '';
    
    // Handle photo upload
    $photo = null; // Default value for photo
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
        $photoTmpName = $_FILES['photo']['tmp_name'];
        $photoName = basename($_FILES['photo']['name']);
        $photoDir = '../uploads/'; // Directory where photos will be uploaded
        $photoPath = $photoDir . $photoName;

        // Move the uploaded file to the specified directory
        if (!file_exists($photoDir)) {
            mkdir($photoDir, 0777, true); // Create the directory if it doesn't exist
        }

        if (move_uploaded_file($photoTmpName, $photoPath)) {
            $photo = $photoPath; // Set the photo path if upload is successful
        } else {
            $errorMessage = "Error uploading photo.";
        }
    }

    // Ensure 'hod_id' is set in the session
    if (!isset($_SESSION['hod_id'])) {
        die("Error: HOD ID not set in session.");
    }

    // Get HOD ID from session
    $hod_id = $_SESSION['hod_id'];

    // Prepare the SQL statement to update the HOD's profile in the 'hods' table
    $sql = "UPDATE hods SET 
        designation = ?, 
        age = ?, 
        specialization = ?, 
        university = ?, 
        currently_teaching = ?, 
        portfolio = ?,
        photo = ? 
        WHERE id = ?"; // Adjust 'id' to match your actual primary key column name

    // Prepare and bind the SQL statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('sssssssi', 
            $designation, $age, $specialization, $university, 
            $currently_teaching, $portfolio, $photo, $hod_id
        );

        // Execute the query
        if ($stmt->execute()) {
            echo "<p>Profile updated successfully.</p>";
        } else {
            $errorMessage = "Error updating profile: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        $errorMessage = "Error preparing the statement: " . $conn->error;
    }
}

// Fetch previously stored details for the HOD to display in the form
if (isset($_SESSION['hod_id'])) { // Check if hod_id is set
    $hod_id = $_SESSION['hod_id']; // Assuming this is set after login
    $sql = "SELECT * FROM hods WHERE id = ?"; // Use the correct primary key
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $hod_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $hod_data = $result->fetch_assoc();
    $stmt->close();
} else {
    die("Error: HOD ID not set in session.");
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update HOD Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            max-width: 400px;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 2px 2px 12px rgba(0, 0, 0, 0.1);
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], input[type="file"], input[type="submit"] {
            margin-bottom: 15px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
        }
        .profile-photo {
            margin-bottom: 15px;
        }
        .profile-photo img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h2>Update HOD Profile</h2>
    <?php if ($errorMessage): ?>
        <p class="error"><?= $errorMessage ?></p>
    <?php endif; ?>
    
    <div class="profile-photo">
        <?php if (!empty($hod_data['photo'])): ?>
            <img src="<?= $hod_data['photo'] ?>" alt="Profile Photo">
        <?php else: ?>
            <p>No profile photo uploaded.</p>
        <?php endif; ?>
    </div>
    
    <form action="hods_profile.php" method="post" enctype="multipart/form-data">
        <label for="designation">Designation:</label>
        <input type="text" name="designation" id="designation" value="<?= $hod_data['designation'] ?? '' ?>" required>

        <label for="age">Age:</label>
        <input type="number" name="age" id="age" value="<?= $hod_data['age'] ?? '' ?>" required min="1">

        <label for="specialization">Specialization:</label>
        <input type="text" name="specialization" id="specialization" value="<?= $hod_data['specialization'] ?? '' ?>" required>

        <label for="university">University:</label>
        <input type="text" name="university" id="university" value="<?= $hod_data['university'] ?? '' ?>" required>

        <label for="currently_teaching">Currently Teaching:</label>
        <input type="text" name="currently_teaching" id="currently_teaching" value="<?= $hod_data['currently_teaching'] ?? '' ?>" required>

        <label for="portfolio">Portfolio:</label>
        <input type="text" name="portfolio" id="portfolio" value="<?= $hod_data['portfolio'] ?? '' ?>">

        <label for="photo">Upload Photo:</label>
        <input type="file" name="photo" id="photo" accept="image/*">

        <input type="submit" value="Update Profile">
    </form>
</body>
</html>

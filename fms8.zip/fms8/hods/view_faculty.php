<?php
include '../includes/db.php';

// Assuming you have already started the session and have the HOD ID
session_start();
$hod_id = $_SESSION['hod_id'];

// Get the department of the HOD
$query = "SELECT department FROM hods WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $hod_id);
$stmt->execute();
$stmt->bind_result($hod_department);
$stmt->fetch();
$stmt->close();

// Fetch faculty members from the same department
$query = "SELECT first_name, last_name, email FROM faculty WHERE department = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $hod_department);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . htmlspecialchars($row['first_name']) . "</td><td>" . htmlspecialchars($row['last_name']) . "</td><td>" . htmlspecialchars($row['email']) . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No faculty members found.";
}

$stmt->close();
?>

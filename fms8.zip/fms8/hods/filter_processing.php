<?php 
include '../includes/db.php';

// Assuming you have already started the session and have the HOD ID
session_start();
$hod_id = $_SESSION['hod_id'];

// Get the department of the HOD
$query = "SELECT department FROM hods WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $hod_id);
$stmt->execute();
$stmt->bind_result($hod_department);
$stmt->fetch();
$stmt->close();

// Initialize filtering variables
$filters = [];
$params = [$hod_department];
$sqlFilters = [];

// Build the SQL query based on filters
$query = "SELECT first_name, last_name, email, age, qualification, specialization, experience, university, designation, currently_teaching FROM faculty WHERE department = ?";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect filters from the form submission
    // Age Filter
    if (!empty($_POST['age'])) {
        $age_operator = $_POST['age_operator'];
        $age_value = $_POST['age'];
        $filters['age'] = $age_value; // Store the value for future use
        $sqlFilters[] = "age $age_operator ?";
        $params[] = $age_value; // Add the value to the parameters
    }

    // Date of Joining Filter
    if (!empty($_POST['doj'])) {
        $doj = $_POST['doj'];
        $sqlFilters[] = "doj = ?";
        $params[] = $doj; // Add the value to the parameters
    }

    // Qualification Filter
    if (!empty($_POST['qualification'])) {
        $qualification = $_POST['qualification'];
        $sqlFilters[] = "qualification LIKE ?";
        $params[] = "%$qualification%"; // Use LIKE for partial matches
    }

    // Specialization Filter
    if (!empty($_POST['specialization'])) {
        $specialization = $_POST['specialization'];
        $sqlFilters[] = "specialization LIKE ?";
        $params[] = "%$specialization%"; // Use LIKE for partial matches
    }

    // Experience Filter
    if (!empty($_POST['experience'])) {
        $experience_operator = $_POST['experience_operator'];
        $experience_value = $_POST['experience'];
        $filters['experience'] = $experience_value; // Store the value for future use
        $sqlFilters[] = "experience $experience_operator ?";
        $params[] = $experience_value; // Add the value to the parameters
    }

    // University Filter
    if (!empty($_POST['university'])) {
        $university = $_POST['university'];
        $sqlFilters[] = "university LIKE ?";
        $params[] = "%$university%"; // Use LIKE for partial matches
    }

    // Designation Filter
    if (!empty($_POST['designation'])) {
        $designation = $_POST['designation'];
        $sqlFilters[] = "designation LIKE ?";
        $params[] = "%$designation%"; // Use LIKE for partial matches
    }

    // Currently Teaching Filter
    if (!empty($_POST['currently_teaching'])) {
        $currently_teaching = $_POST['currently_teaching'];
        $sqlFilters[] = "currently_teaching LIKE ?";
        $params[] = "%$currently_teaching%"; // Use LIKE for partial matches
    }
}

// Append additional filters to the query if they exist
if (!empty($sqlFilters)) {
    $query .= " AND " . implode(" AND ", $sqlFilters);
}

// Prepare and execute the query
$stmt = $conn->prepare($query);
$stmt->bind_param(str_repeat("s", count($params)), ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Apply some basic styling to the table and button
    echo "<style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        table, th, td {
            border: 1px solid #dddddd;
            padding: 12px 15px;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .center-button {
            text-align: center;
        }
    </style>";

    echo "<form method='POST' action='download_csv.php'>";
    echo "<table><tr><th>First Name</th><th>Last Name</th><th>Email</th><th>Age</th><th>Qualification</th><th>Specialization</th><th>Experience</th><th>University</th><th>Designation</th><th>Currently Teaching</th></tr>";

    $faculty_data = [];
    while ($row = $result->fetch_assoc()) {
        $faculty_data[] = $row; // Collect faculty data for CSV
        echo "<tr><td>" . htmlspecialchars($row['first_name']) . "</td>
                  <td>" . htmlspecialchars($row['last_name']) . "</td>
                  <td>" . htmlspecialchars($row['email']) . "</td>
                  <td>" . htmlspecialchars($row['age']) . "</td>
                  <td>" . htmlspecialchars($row['qualification']) . "</td>
                  <td>" . htmlspecialchars($row['specialization']) . "</td>
                  <td>" . htmlspecialchars($row['experience']) . "</td>
                  <td>" . htmlspecialchars($row['university']) . "</td>
                  <td>" . htmlspecialchars($row['designation']) . "</td>
                  <td>" . htmlspecialchars($row['currently_teaching']) . "</td></tr>";
    }
    echo "</table>";

    // Store the results in a hidden input field for CSV export
    echo "<input type='hidden' name='faculty_data' value='" . base64_encode(serialize($faculty_data)) . "'>";
    
    // Button to download CSV
    echo "<div class='center-button'><button type='submit' formaction='download_csv.php'>Download CSV</button></div>";
    echo "</form>";
} else {
    echo "<p>No faculty members found.</p>";
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Faculty</title>
    <style>
        /* General Page Styling */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            background-color: #f0f2f5;
            color: #333;
        }

        /* Styling for Left and Right Frames */
        #left-frame {
            width: 25%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-right: 1px solid #ccc;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
        }

        #right-frame {
            width: 75%;
            padding: 20px;
            overflow-y: auto;
            background-color: #fff;
        }

        /* Button Styling */
        .nav-button {
            display: block;
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            background-color: #007bff;
            color: white;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 123, 255, 0.3);
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .nav-button:hover {
            background-color: #0056b3;
            box-shadow: 0 6px 10px rgba(0, 123, 255, 0.5);
        }

        /* Iframe Styling */
        iframe {
            width: 100%;
            height: calc(100vh - 40px); /* Ensure iframe fills available height */
            border: none;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            transition: transform 0.3s ease-in-out;
        }

        /* Smooth transition for iframe content */
        iframe.entering {
            transform: translateX(100%);
        }

        iframe.loaded {
            transform: translateX(0);
        }

        /* Header Styles */
        h1 {
            font-size: 22px;
            color: #007bff;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Flexbox alignment for better presentation */
        #left-frame div {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    </style>
</head>
<body>
    <div id="left-frame">
        <h1>Manage Faculty</h1>
        <div>
            <!-- Button for loading View Faculty content in the right frame -->
            <a href="#" class="nav-button" onclick="loadContent('view_faculty')">View Faculty</a>
            <!-- Button for opening Filter Faculty in a new webpage -->
            <a href="hod_filter_faculty.php" target="_blank" class="nav-button">Filter Faculty</a>
        </div>
    </div>
    
    <div id="right-frame">
        <!-- Right frame for loading the view_faculty.php content -->
        <iframe id="content-frame" class="entering"></iframe>
    </div>

    <script>
        // Function to load content into the iframe with smooth transitions
        function loadContent(option) {
            let iframe = document.getElementById('content-frame');
            if (option === 'view_faculty') {
                iframe.classList.remove('loaded');
                iframe.src = 'view_faculty.php'; // Load the faculty view in the right frame
                iframe.onload = function() {
                    iframe.classList.add('loaded');
                };
            }
        }
    </script>
</body>
</html>

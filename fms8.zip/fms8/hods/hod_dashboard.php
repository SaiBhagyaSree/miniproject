<?php
session_start();
if (!isset($_SESSION['hod_logged_in'])) {
    header('Location: hod_login.php');
    exit();
}

// Database connection details
$host = 'localhost';
$username = 'root'; // Replace with your actual database username
$password = ''; // Replace with your actual database password
$database = 'faculty_management_system'; // Replace with your actual database name

// Create a new mysqli instance
$mysqli = new mysqli($host, $username, $password, $database);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch profile details
$id = $_SESSION['hod_id'];
$result = $mysqli->query("SELECT * FROM hods WHERE id = $id");
$profile = $result->fetch_assoc();

// Check if profile is incomplete
$profile_incomplete = empty($profile['designation']) || empty($profile['age']) || empty($profile['specialization']) || empty($profile['university']) || empty($profile['dob']) || empty($profile['doj']);

// Close the database connection
$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            padding: 20px;
            background-color: #007bff;
            color: #ffffff;
            margin: 0;
            font-size: 26px;
        }

        .container {
            display: flex;
            height: calc(100vh - 60px);
        }

        .left-frame {
            width: 25%;
            background-color: #343a40;
            padding: 20px;
            box-sizing: border-box;
            color: #ffffff;
        }

        .left-frame ul {
            list-style-type: none;
            padding: 0;
        }

        .left-frame li {
            margin-bottom: 20px;
        }

        .left-frame a {
            color: #ffffff;
            text-decoration: none;
            font-size: 18px;
            display: block;
            padding: 10px;
            background-color: #495057;
            border-radius: 5px;
            text-align: center;
        }

        .left-frame a:hover {
            background-color: #adb5bd;
            color: #343a40;
        }

        .right-frame {
            width: 75%;
            padding: 20px;
            box-sizing: border-box;
            background-color: #ffffff;
            border-left: 2px solid #007bff;
            overflow-y: auto;
            position: relative;
        }

        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .profile-photo {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 3px solid #007bff;
            object-fit: cover;
            background-color: #f8f9fa;
        }

        .update-message {
            padding: 10px;
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['hod_lastname']); ?></h1>
    <div class="container">
        <div class="left-frame">
            <ul>
                <li><a href="hod_profile.php" target="right-frame">Profile</a></li>
                <li><a href="hod_manage_faculty.php" target="right-frame">Manage Faculty</a></li>
                <li><a href="hod_notifications.php" target="right-frame">Notifications</a></li>
            </ul>
        </div>
        <div class="right-frame">
            <?php if ($profile['photo']): ?>
                <img src="<?php echo htmlspecialchars($profile['photo']); ?>" alt="Profile Photo" class="profile-photo">
            <?php else: ?>
                <img src="../images/default_photo.png" alt="Default Profile Photo" class="profile-photo">
            <?php endif; ?>
            
            <!-- Iframe to load different pages dynamically -->
            <iframe name="right-frame" src="hod_profile.php"></iframe>
        </div>
    </div>
</body>
</html>

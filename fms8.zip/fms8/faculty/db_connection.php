<?php
$host = 'localhost'; // Replace with your actual host
$username = 'root'; // Replace with your actual database username
$password = ''; // Replace with your actual database password
$database = 'faculty_management_system'; // Replace with your actual database name

// Create a new mysqli instance
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

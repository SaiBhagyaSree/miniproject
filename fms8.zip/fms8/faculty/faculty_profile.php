<?php
session_start(); // Start the session

// Check if the faculty is logged in and the faculty_id is set
if (!isset($_SESSION['faculty_logged_in']) || !isset($_SESSION['faculty_id'])) {
    header('Location: faculty_login.php'); // Redirect to login if not logged in
    exit();
}

// Database connection
$mysqli = new mysqli('localhost', 'root', '', 'faculty_management_system');

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Initialize profile data
$profile = [
    'designation' => '',
    'age' => '',
    'specialization' => '',
    'university' => '',
    'previous_experience' => '',
    'course_details' => '',
    'currently_teaching' => '',
    'portfolio' => '',
    'photo' => '',
    'resume' => '',
    'learnings' => '',
    'achievements' => ''
];

// Fetch current profile data
$id = $_SESSION['faculty_id']; // Get the faculty ID from the session
$result = $mysqli->query("SELECT * FROM faculty WHERE id = $id");
if ($result) {
    $profile = $result->fetch_assoc();
} else {
    echo "Error fetching profile data: " . $mysqli->error;
}

// Parse course details and ensure that it properly populates form fields
$courses = [
    ['name' => '', 'times' => '0'], 
    ['name' => '', 'times' => '0'], 
    ['name' => '', 'times' => '0']
];
if (!empty($profile['course_details'])) {
    $courseEntries = explode('; ', $profile['course_details']);
    foreach ($courseEntries as $index => $entry) {
        if (!empty($entry)) {
            list($courseName, $times) = explode(': ', $entry);
            $courses[$index] = ['name' => $courseName, 'times' => $times];
        }
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_SESSION['faculty_id']; // Get the faculty ID from the session

    // Retrieve POST data
    $designation = $_POST['designation'];
    $age = $_POST['age'];
    $specialization = $_POST['specialization'];
    $university = $_POST['university'];
    $previous_experience = $_POST['previous_experience_1'] . '; ' . $_POST['previous_experience_2'];
    $course1 = $_POST['course1'];
    $course1_times = $_POST['course1_times'];
    $course2 = $_POST['course2'];
    $course2_times = $_POST['course2_times'];
    $course3 = $_POST['course3'];
    $course3_times = $_POST['course3_times'];
    $currently_teaching = $_POST['currently_teaching'];
    $portfolio = $_POST['portfolio'];

    // Combine course details into a single string
    $course_details = "{$course1}: {$course1_times}; {$course2}: {$course2_times}; {$course3}: {$course3_times}";

    // Handle file uploads
    $photo = handleFileUpload('photo', 'photos/');
    $resume = handleFileUpload('resume', 'resumes/');
    $learnings = handleMultipleFileUploads('learnings', 'learnings/');
    $achievements = handleMultipleFileUploads('achievements', 'achievements/');

    // Prepare and execute SQL update query
    $stmt = $mysqli->prepare("UPDATE faculty SET 
        designation = ?, age = ?, specialization = ?, university = ?, 
        previous_experience = ?, course_details = ?, currently_teaching = ?, 
        portfolio = ?, photo = IF(? != '', ?, photo), 
        resume = IF(? != '', ?, resume), 
        learnings = IF(? != '', ?, learnings), 
        achievements = IF(? != '', ?, achievements) 
        WHERE id = ?");
    $stmt->bind_param('sissssssssssssssi', 
        $designation, $age, $specialization, $university, 
        $previous_experience, $course_details, $currently_teaching, $portfolio,
        $photo, $photo, $resume, $resume, $learnings, $learnings, $achievements, $achievements, $id);

    if ($stmt->execute()) {
        echo "Profile updated successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
}

// Handle file upload
function handleFileUpload($fileInputName, $uploadDir) {
    // Ensure the directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (isset($_FILES[$fileInputName]) && $_FILES[$fileInputName]['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES[$fileInputName]['tmp_name'];
        $fileName = $_FILES[$fileInputName]['name'];
        $destination = $uploadDir . $fileName;
        
        if (move_uploaded_file($fileTmpPath, $destination)) {
            return $destination;
        } else {
            return '';
        }
    }
    return '';
}

// Handle multiple file uploads
function handleMultipleFileUploads($fileInputName, $uploadDir) {
    // Ensure the directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (isset($_FILES[$fileInputName]) && $_FILES[$fileInputName]['error'][0] === UPLOAD_ERR_OK) {
        $fileNames = [];
        foreach ($_FILES[$fileInputName]['name'] as $key => $name) {
            $fileTmpPath = $_FILES[$fileInputName]['tmp_name'][$key];
            $destination = $uploadDir . $name;
            
            if (move_uploaded_file($fileTmpPath, $destination)) {
                $fileNames[] = $destination;
            }
        }
        return implode(';', $fileNames);
    }
    return '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px 15px;
            background-color: #5cb85c;
            border: none;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Faculty Profile</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="designation">Designation:</label>
            <input type="text" name="designation" id="designation" value="<?php echo htmlspecialchars($profile['designation']); ?>">
        </div>
        <div class="form-group">
            <label for="age">Age:</label>
            <input type="number" name="age" id="age" value="<?php echo htmlspecialchars($profile['age']); ?>">
        </div>
        <div class="form-group">
            <label for="specialization">Specialization:</label>
            <input type="text" name="specialization" id="specialization" value="<?php echo htmlspecialchars($profile['specialization']); ?>">
        </div>
        <div class="form-group">
            <label for="university">University:</label>
            <input type="text" name="university" id="university" value="<?php echo htmlspecialchars($profile['university']); ?>">
        </div>
        <div class="form-group">
            <label for="previous_experience_1">Previous Experience 1:</label>
            <input type="text" name="previous_experience_1" id="previous_experience_1" value="<?php echo htmlspecialchars(explode('; ', $profile['previous_experience'])[0]); ?>">
        </div>
        <div class="form-group">
            <label for="previous_experience_2">Previous Experience 2:</label>
            <input type="text" name="previous_experience_2" id="previous_experience_2" value="<?php echo htmlspecialchars(explode('; ', $profile['previous_experience'])[1]); ?>">
        </div>
        <div class="form-group">
            <label for="course1">Course 1:</label>
            <input type="text" name="course1" id="course1" value="<?php echo htmlspecialchars($courses[0]['name']); ?>">
            <label for="course1_times">Times Taught 1:</label>
            <input type="number" name="course1_times" id="course1_times" value="<?php echo htmlspecialchars($courses[0]['times']); ?>">
        </div>
        <div class="form-group">
            <label for="course2">Course 2:</label>
            <input type="text" name="course2" id="course2" value="<?php echo htmlspecialchars($courses[1]['name']); ?>">
            <label for="course2_times">Times Taught 2:</label>
            <input type="number" name="course2_times" id="course2_times" value="<?php echo htmlspecialchars($courses[1]['times']); ?>">
        </div>
        <div class="form-group">
            <label for="course3">Course 3:</label>
            <input type="text" name="course3" id="course3" value="<?php echo htmlspecialchars($courses[2]['name']); ?>">
            <label for="course3_times">Times Taught 3:</label>
            <input type="number" name="course3_times" id="course3_times" value="<?php echo htmlspecialchars($courses[2]['times']); ?>">
        </div>
        <div class="form-group">
            <label for="currently_teaching">Currently Teaching:</label>
            <input type="text" name="currently_teaching" id="currently_teaching" value="<?php echo htmlspecialchars($profile['currently_teaching']); ?>">
        </div>
        <div class="form-group">
            <label for="portfolio">Portfolio (Optional):</label>
            <textarea name="portfolio" id="portfolio"><?php echo htmlspecialchars($profile['portfolio']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="photo">Upload Photo:</label>
            <input type="file" name="photo" id="photo">
        </div>
        <div class="form-group">
            <label for="resume">Upload Resume:</label>
            <input type="file" name="resume" id="resume">
        </div>
        <div class="form-group">
            <label for="learnings">Upload Learnings:</label>
            <input type="file" name="learnings[]" id="learnings" multiple>
        </div>
        <div class="form-group">
            <label for="achievements">Upload Achievements:</label>
            <input type="file" name="achievements[]" id="achievements" multiple>
        </div>
        <div class="form-group">
            <button type="submit">Update Profile</button>
        </div>
    </form>
</div>

</body>
</html>

<?php
require '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

$success_message = ""; // Variable to store success message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $qualification = $_POST['qualification'];
    $experience = $_POST['experience'];
    $doj = $_POST['doj'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $aadhar = $_POST['aadhar'];
    $department = $_POST['department'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Determine which table to insert based on role
    if ($role == 'faculty') {
        $table = 'faculty';
    } elseif ($role == 'hod') {
        $table = 'hods';
    } else {
        $table = 'higher_officials';
    }

    // SQL query to insert data
    $sql = "INSERT INTO $table (first_name, last_name, qualification, experience, doj, dob, email, phone, aadhar, department, username, password)
            VALUES ('$first_name', '$last_name', '$qualification', '$experience', '$doj', '$dob', '$email', '$phone', '$aadhar', '$department', '$username', '$password')";

    // Execute query and check for success
    if ($conn->query($sql) === TRUE) {
        // Set success message
        $success_message = "Details saved successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Member</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h2 {
            text-align: center;
            color: #007bff;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input, select, button {
            margin-top: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .success-message {
            text-align: center;
            color: green;
            font-size: 18px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add New Member</h2>

        <!-- Display success message if details were saved -->
        <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label for="role">Role:</label>
            <select name="role" id="role" required>
                <option value="faculty">Faculty</option>
                <option value="hod">HOD</option>
                <option value="higher_official">Higher Official</option>
            </select>

            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" id="first_name" required>

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" id="last_name" required>

            <label for="qualification">Qualification:</label>
            <input type="text" name="qualification" id="qualification" required>

            <label for="experience">Previous Experience:</label>
            <input type="text" name="experience" id="experience" required>

            <label for="doj">Date of Joining:</label>
            <input type="date" name="doj" id="doj" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" id="dob" required>

            <label for="email">Personal Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="phone">Phone Number:</label>
            <input type="text" name="phone" id="phone" required pattern="[0-9]{10}">

            <label for="aadhar">Aadhar Number:</label>
            <input type="text" name="aadhar" id="aadhar" required pattern="[0-9]{12}">

            <label for="department">Department:</label>
            <input type="text" name="department" id="department" required>

            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Save</button>
        </form>
    </div>
</body>
</html>

<?php
require '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];
    $username = $_POST['username'];

    if ($role == 'faculty') {
        $table = 'faculty';
    } elseif ($role == 'hod') {
        $table = 'hods';
    } else {
        $table = 'higher_officials';
    }

    $sql = "DELETE FROM $table WHERE username='$username'";

    if ($conn->query($sql) === TRUE) {
        $success = "User deleted successfully.";
    } else {
        $error = "Error deleting user: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Member</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h2>Delete Member</h2>
    <form method="POST">
        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="faculty">Faculty</option>
            <option value="hod">HOD</option>
            <option value="higher_official">Higher Official</option>
        </select>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        <button type="submit">Delete</button>
    </form>

    <?php if (isset($error)) echo "<p>$error</p>"; ?>
    <?php if (isset($success)) echo "<p>$success</p>"; ?>
</body>
</html>

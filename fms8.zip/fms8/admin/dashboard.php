<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        .dashboard-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        h2 {
            font-size: 28px;
            color: #007bff;
            margin-bottom: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }

        ul li {
            display: inline-block;
            margin: 0 10px;
        }

        ul li a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        ul li a:hover {
            background-color: #0056b3;
        }

        .dashboard-footer {
            margin-top: 40px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="dashboard-container">
        <h2>Admin Dashboard</h2>
        <ul>
            <li><a href="new_member.php">New Member</a></li>
            <li><a href="edit_details.php">Edit Details</a></li>
            <li><a href="delete_details.php">Delete Details</a></li>
            <li><a href="#">Notifications</a></li>
        </ul>
        <div class="dashboard-footer">
            <p>&copy; 2024 Faculty Management System. All Rights Reserved.</p>
        </div>
    </div>

</body>
</html>

<?php
require '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $role = $_POST['role'];
    $username = $_POST['username'];

    if ($role == 'faculty') {
        $table = 'faculty';
    } elseif ($role == 'hod') {
        $table = 'hods';
    } else {
        $table = 'higher_officials';
    }

    $sql = "SELECT * FROM $table WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        $error = "No user found with username $username.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    // Process update
    $role = $_POST['role'];
    $username = $_POST['username'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $qualification = $_POST['qualification'];
    $experience = $_POST['experience'];
    $doj = $_POST['doj'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $aadhar = $_POST['aadhar'];
    $department = $_POST['department'];

    $sql = "UPDATE $table SET first_name='$first_name', last_name='$last_name', qualification='$qualification', experience='$experience',
            doj='$doj', dob='$dob', email='$email', phone='$phone', aadhar='$aadhar', department='$department' WHERE username='$username'";

    if ($conn->query($sql) === TRUE) {
        $success = "Details updated successfully.";
    } else {
        $error = "Error updating details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Details</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <h2>Edit Member Details</h2>
    <form method="POST">
        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="faculty">Faculty</option>
            <option value="hod">HOD</option>
            <option value="higher_official">Higher Official</option>
        </select>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>
        <button type="submit">Edit</button>
    </form>

    <?php if (isset($user)): ?>
        <form method="POST">
            <input type="hidden" name="role" value="<?= $role ?>">
            <input type="hidden" name="username" value="<?= $username ?>">
            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" id="first_name" value="<?= $user['first_name'] ?>" required>
            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" id="last_name" value="<?= $user['last_name'] ?>" required>
            <label for="qualification">Qualification:</label>
            <input type="text" name="qualification" id="qualification" value="<?= $user['qualification'] ?>" required>
            <label for="experience">Previous Experience:</label>
            <input type="text" name="experience" id="experience" value="<?= $user['experience'] ?>" required>
            <label for="doj">Date of Joining:</label>
            <input type="date" name="doj" id="doj" value="<?= $user['doj'] ?>" required>
            <label for="dob">Date of Birth:</label>
            <input type="date" name="dob" id="dob" value="<?= $user['dob'] ?>" required>
            <label for="email">Personal Email:</label>
            <input type="email" name="email" id="email" value="<?= $user['email'] ?>" required>
            <label for="phone">Phone Number:</label>
            <input type="text" name="phone" id="phone" value="<?= $user['phone'] ?>" required pattern="[0-9]{10}">
            <label for="aadhar">Aadhar Number:</label>
            <input type="text" name="aadhar" id="aadhar" value="<?= $user['aadhar'] ?>" required pattern="[0-9]{12}">
            <label for="department">Department:</label>
            <input type="text" name="department" id="department" value="<?= $user['department'] ?>" required>
            <button type="submit" name="save">Save</button>
        </form>
    <?php endif; ?>

    <?php if (isset($error)) echo "<p>$error</p>"; ?>
    <?php if (isset($success)) echo "<p>$success</p>"; ?>
</body>
</html>
